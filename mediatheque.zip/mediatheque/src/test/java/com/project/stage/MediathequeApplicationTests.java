package com.project.stage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediathequeApplicationTests {

	@Test
	void contextLoads() {
	}

}
